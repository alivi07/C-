#include <iostream>
#include <cstdlib>
#include <string.h>
#include <iomanip>


using namespace std;

void input ();
void output ();
void pindah ();

void seq_no ();
void seq_nama ();
void seq_umur ();
void seq_gender ();

void bin_no ();
void bin_nama();
void bin_umur ();
void bin_gender ();

void tampil_sorting ();

void bubble_no (int z);
void bubble_nama (int z);
void bubble_umur (int z);
void bubble_gender (int z);

void insertion_no (int z);
void insertion_nama (int z);
void insertion_umur (int z);
void insertion_gender (int z);

void selection_no (int  z);
void selection_nama (int z);
void selection_umur (int z);
void selection_gender (int z);

void shell_no (int z);
void shell_nama (int z);
void shell_umur (int z);
void shell_gender (int z);

void quick_no (int first, int last, int z);
void quick_nama (int first, int last, int z);
void quick_umur (int first, int last, int z);
void quick_gender (int first, int last, int z);

int pilih,pilih2,n,oke; // n=jumlah banyak data,
FILE *arsip_pasien;
typedef struct
{
	int no,umur;
	char nama[30],gender[10];
} data ;
data a[100];
data baru[100];

int main ()
{
	int pilih;
	do
	{
	
	cout << setw (10) << "\t\t==========================================" << endl;
	cout << setw (10) << "\t\t||          MENU PROJECT AKHIR          ||" << endl;
	cout << setw (10) << "\t\t==========================================" << endl;
	cout << setw (10) << "\t\t>> 1. Input Data" << endl;
	cout << setw (10) << "\t\t>> 2. Output Data" << endl;
	cout << setw (10) << "\t\t>> 3. Searching Data" << endl;
	cout << setw (10) << "\t\t>> 4. Sorting Data" << endl;
	cout << setw (10) << "\t\t>> 5. Exit" << endl;
	cout << setw (10) << "\n\t\tMasukkan Pilihan Anda : " ;
	cin >> pilih;
	
	system ("cls");
	switch (pilih)
	{
		case 1 :
				{
					input ();
					cout << "\n\n" ;
					
				}
				break ;	
				
		case 2 :
				{	
					output ();
					cout << "\n\n" ;
				}
				break ;
		case 3 :
				{ 
					cout << "\n\n\t\t==========================================" << endl;
					cout << "\t\t||             MENU SERCHING            ||" << endl;
					cout << "\t\t==========================================" << endl;
					cout << "\t\t>> 1.Sequential" << endl;
					cout << "\t\t>> 2.Binarry" << endl;
					cout << "\t\tMasukkan pilihan Anda : " ;
					cin >> pilih2;
					
					system ("cls");
					switch (pilih2)
					{
						case 1 :
								{
									int pilih3;
									
									cout << "\n\n\t\t==========================================" << endl;
									cout << "\t\t||                  MENU                 ||" << endl;
									cout << "\t\t==========================================" << endl;
									cout << "\t\t>> 1.Pake Nomor" << endl;
									cout << "\t\t>> 2.Pake Nama" << endl;
									cout << "\t\t>> 3.Pake Umur" << endl;
									cout << "\t\t>> 4.Pake Jenis Kelamin" << endl;
									cout << "\t\tMasukkan pilihan Anda : " ;
									cin >> pilih3;
									
									system ("cls");
									switch (pilih3)
										{
											case 1 :
											{
												seq_no ();
												}break ;
											
											case 2 :
												{
												 seq_nama ();
												}break ;
											case 3 :
												{
													seq_umur ();
												}break;
											
											case 4 :
												{
													seq_gender ();
												}break;
											case 5 :
												{
													{ exit (0); }
													default :
												cout << "Nomor Yang Anda Masukkan Salah!!!!!!" <<endl;
													
												}break;
										}
								}break ;
							
						case 2:
								{
									int pilih4;
								
									cout << "\n\n\t\t==========================================" << endl;
									cout << "\t\t||                  MENU                 ||" << endl;
									cout << "\t\t==========================================" << endl;
									cout << "\t\t>> 1.Pake Nomor" << endl;
									cout << "\t\t>> 2.Pake Nama" << endl;
									cout << "\t\t>> 3.Pake Umur" << endl;
									cout << "\t\t>> 4.Pake Jenis Kelamin" << endl;
									cout << "\t\tMasukkan pilihan Anda : " ;
									cin >> pilih4;
									
									system ("cls");
									switch (pilih4)
										{
											case 1 :
												{
													bin_no ();
												}break;
											case 2 :
												{
													bin_nama();
												}break;
											case 3 :
												{
													bin_umur ();
												}break;
											case 4 :
												{
													bin_gender ();
												}break;
											case 5 :
												{
													{ exit (0); }
													default :
													cout << "Nomor Yang Anda Masukkan Salah!!!!!!" <<endl;
												}break;
											
										}
						
								}break;
						case 3:
								{
									{ exit (0); }
													default :
												cout << "Nomor Yang Anda Masukkan Salah!!!!!!" <<endl;
								}break;
					}
				}break;
	
			case 4 : 
			       {
				         int pilih4;
								
								cout << "\n\n\t\t==========================================" << endl;
								cout << "\t\t||             MENU SORTING             ||" << endl;
								cout << "\t\t==========================================" << endl;
								cout << "\t\t>> 1. Bubble Sort" << endl;
								cout << "\t\t>> 2. Insertion Sort" << endl;
								cout << "\t\t>> 3. Selection Sort" << endl;
								cout << "\t\t>> 4. Shell Sort" << endl;
								cout << "\t\t>> 5. Quick Sort" << endl;
								cout << "\t\tMasukkan pilihan Anda : " ;
								cin >> pilih4;
								
								system ("cls");
								switch (pilih4)
								{
									case 1 :
										{
											
													int pilih5,pilih10;
													cout << "\n\n\t\t==========================================" << endl;
													cout << "\t\t||                  MENU                 ||" << endl;
													cout << "\t\t==========================================" << endl;
													cout << "\t\t>> 1. Urutin NO" << endl;
													cout << "\t\t>> 2. Urutin Nama" << endl;
													cout << "\t\t>> 3. Urutin Umur" << endl;
													cout << "\t\t>> 4. Urutin Jenis Kelamin" << endl;
													cout << "\t\tMasukkan pilihan Anda : " ;
													cin >> pilih5;
													
													system ("cls");
													cout << "\n\n\t\t==========================================" << endl;
													cout << "\t\t||                  MENU                 ||" << endl;
													cout << "\t\t==========================================" << endl;
													cout << "\t\t>> 1. Ascending" << endl;
													cout << "\t\t>> 2. Discending" << endl;
													cout << "\t\tMasukkan pilihan Anda : " ;
													cin >> pilih10;
													
													system ("cls");
													switch (pilih5)
													{
														case 1:
															{
																pindah ();
																bubble_no (pilih10);
																tampil_sorting();
																
															}break;
														case 2 :
															{
																pindah ();
																bubble_nama (pilih10);
																tampil_sorting ();
															}break ;
														case 3 :
															{
																pindah ();
																bubble_umur (pilih10);
																tampil_sorting ();
															}break;
														case 4 :
															{
																pindah ();
																bubble_gender (pilih10);
																tampil_sorting ();
															}break;
														case 5 :
															{
															{ exit (0); }
															default :
															cout << "Nomor Yang Anda Masukkan Salah!!!!!!" <<endl;
															}break;
													}
											
										}break ;
									case 2 :
										{ 
													int pilih6,pilih11;
													cout << "\n\n\t\t==========================================" << endl;
													cout << "\t\t||                  MENU                 ||" << endl;
													cout << "\t\t==========================================" << endl;
													cout << "\t\t>> 1. Urutin NO" << endl;
													cout << "\t\t>> 2. Urutin Nama" << endl;
													cout << "\t\t>> 3. Urutin Umur" << endl;
													cout << "\t\t>> 4. Urutin Jenis Kelamin" << endl;
													cout << "\t\tMasukkan pilihan Anda : " ;
													cin >> pilih6;
													
													system ("cls");
													cout << "\n\n\t\t==========================================" << endl;
													cout << "\t\t||                  MENU                 ||" << endl;
													cout << "\t\t==========================================" << endl;
													cout << "\t\t>> 1. Ascending" << endl;
													cout << "\t\t>> 2. Discending" << endl;
													cout << "\t\tMasukkan pilihan Anda : " ;
													cin >> pilih11;
													system ("cls");
													switch (pilih6)
													{
														case 1:
															{
																pindah ();
																insertion_no (pilih11);
																tampil_sorting ();
																
															}break;
														case 2 :
															{
																pindah ();
																insertion_nama (pilih11);														
																tampil_sorting ();
															}break ;
														case 3 :
															{
																pindah ();
																insertion_umur (pilih11);
																tampil_sorting ();
															}break;
														case 4 :
															{
																pindah ();
																insertion_gender (pilih11);
																tampil_sorting ();
															}break;
														case 5 :
															{
															{ exit (0); }
															default :
															cout << "Nomor Yang Anda Masukkan Salah!!!!!!" <<endl;
															}break;
													}
											
										}break;
									case 3 :
										{
											int pilih7,pilih12;
													cout << "\n\n\t\t==========================================" << endl;
													cout << "\t\t||                  MENU                 ||" << endl;
													cout << "\t\t==========================================" << endl;
													cout << "\t\t>> 1. Urutin NO" << endl;
													cout << "\t\t>> 2. Urutin Nama" << endl;
													cout << "\t\t>> 3. Urutin Umur" << endl;
													cout << "\t\t>> 4. Urutin Jenis Kelamin" << endl;
													cout << "\t\tMasukkan pilihan Anda : " ;
													cin >> pilih7;
													
													system ("cls");
													cout << "\n\n\t\t==========================================" << endl;
													cout << "\t\t||                  MENU                 ||" << endl;
													cout << "\t\t==========================================" << endl;
													cout << "\t\t>> 1. Ascending" << endl;
													cout << "\t\t>> 2. Discending" << endl;
													cout << "\t\tMasukkan pilihan Anda : " ;
													
													cin >> pilih12;
													
													system ("cls");
													switch (pilih7)
													{
														case 1:
															{
																pindah ();
																selection_no (pilih12);
																tampil_sorting ();
																
															}break;
														case 2 :
															{
																pindah ();
																selection_nama (pilih12);														
																tampil_sorting ();
															}break ;
														case 3 :
															{
																pindah ();
																selection_umur (pilih12);
																tampil_sorting ();
															}break;
														case 4 :
															{
																pindah ();
																selection_gender (pilih12);
																tampil_sorting ();
															}break;
														case 5 :
															{
															{ exit (0); }
															default :
															cout << "Nomor Yang Anda Masukkan Salah!!!!!!" <<endl;
															}break;
													}
											
										}break;
									case 4 :
										{
											
											int pilih8,pilih13;
													cout << "\n\n\t\t==========================================" << endl;
													cout << "\t\t||                  MENU                 ||" << endl;
													cout << "\t\t==========================================" << endl;
													cout << "\t\t>> 1. Urutin NO" << endl;
													cout << "\t\t>> 2. Urutin Nama" << endl;
													cout << "\t\t>> 3. Urutin Umur" << endl;
													cout << "\t\t>> 4. Urutin Jenis Kelamin" << endl;
													cout << "\t\tMasukkan pilihan Anda : " ;
													cin >> pilih8;
													
													system ("cls");
													cout << "\n\n\t\t==========================================" << endl;
													cout << "\t\t||                  MENU                 ||" << endl;
													cout << "\t\t==========================================" << endl;
													cout << "\t\t>> 1. Ascending" << endl;
													cout << "\t\t>> 2. Discending" << endl;
													cout << "\t\tMasukkan pilihan Anda : " ;
													cin >> pilih13;
													
													system ("cls");
													switch (pilih8)
													{
														case 1:
															{
																pindah ();
																shell_no (pilih13);
																tampil_sorting ();
																
															}break;
														case 2 :
															{
																pindah ();
																shell_nama (pilih13);													
																tampil_sorting ();
															}break ;
														case 3 :
															{
																pindah ();
															shell_umur(pilih13);
																tampil_sorting ();
															}break;
														case 4 :
															{
																pindah ();
																shell_gender (pilih13);
																tampil_sorting ();
															}break;
														case 5 :
															{
															{ exit (0); }
															default :
															cout << "Nomor Yang Anda Masukkan Salah!!!!!!" <<endl;
															}break;
													}
										}break;
									case 5 :
										{
											
											int pilih9,pilih14;
													cout << "\n\n\t\t==========================================" << endl;
													cout << "\t\t||                  MENU                 ||" << endl;
													cout << "\t\t==========================================" << endl;
													cout << "\t\t>> 1. Urutin NO" << endl;
													cout << "\t\t>> 2. Urutin Nama" << endl;
													cout << "\t\t>> 3. Urutin Umur" << endl;
													cout << "\t\t>> 4. Urutin Jenis Kelamin" << endl;
													cout << "\t\tMasukkan pilihan Anda : " ;
													cin >> pilih9;
													
													system ("cls");
													cout << "\n\n\t\t==========================================" << endl;
													cout << "\t\t||                  MENU                 ||" << endl;
													cout << "\t\t==========================================" << endl;
													cout << "\t\t>> 1. Ascending" << endl;
													cout << "\t\t>> 2. Discending" << endl;
													cout << "\t\tMasukkan pilihan Anda : " ;
													cin >> pilih14;
													
													system ("cls");
													switch (pilih9)
													{
														case 1:
															{
																pindah();
																	cout << ">>>>>>>>Proses Sorting<<<<<<<<<\n\n";
																quick_no (0, n-1, pilih14);
																tampil_sorting();
																
															}break;
														case 2 :
															{
																pindah ();
																cout << ">>>>>>>>Proses Sorting<<<<<<<<<\n\n";
																quick_nama (0, n-1, pilih14);											
																tampil_sorting ();
															}break ;
														case 3 :
															{
																pindah ();
																cout << ">>>>>>>>Proses Sorting<<<<<<<<<\n\n";
															quick_umur (0, n-1, pilih14);
																tampil_sorting ();
															}break;
														case 4 :
															{
																pindah ();
																cout << ">>>>>>>>Proses Sorting<<<<<<<<<\n\n";
																quick_gender (0, n-1, pilih14);
																tampil_sorting ();
															}break;
														case 5 :
															{
															{ exit (0); }
															default :
															cout << "Nomor Yang Anda Masukkan Salah!!!!!!" <<endl;
															}break;
													}
										}break;
								}
				       }
						
				
			}
			do
		{
			cout << "Apakah Anda ingin memilih kembali ?" << endl;
			cout << "1. Yes" << endl;
			cout << "2. No" << endl;
			cout << "Masukkan Pilihan  Anda : ";
			cin >> oke ;
			system ("cls") ;
			
				if (oke == 2)
				{ exit (0) ;}
				else if ( oke !=1 && oke !=2)
				cout << "Pilihan anda tidak tersedia!!!\n\n"  ;
		}
		while (oke > 2);
	}while (oke==1);




	
}	


void input()
{
	
			arsip_pasien = fopen("pasien1.txt","w");
			cout << "\n\nMasukkan Jumlah Pasien : ";
					cin >> n;
					fwrite(&n,sizeof(n),1,arsip_pasien);
					for (int i=0;i<n;i++)
					{
							cout << "\n---Pasien" << i+1 << "---" << endl;
							cout << "No Rekam Medis : " ;
							cin >> a[i].no;
							cout << "Nama Pasien : " ;
							cin.ignore();
							cin.getline(a[i].nama,sizeof(a[i].nama));
							cout << "Umur Pasien : " ;
							cin >> a[i].umur;
							cout << "Jenis Kelamin : " ;
							cin >> a[i].gender;
							fwrite (&a, sizeof (a),1,arsip_pasien);
						}
			fwrite (&a, sizeof (a),1,arsip_pasien);
			fclose(arsip_pasien);
}
void output()
{
	cout << "\t\t\t\t\t>>>>>>>>>DATA PASIEN<<<<<<<<<<<<\n\n";
	cout<<"\n===========================================================================================================";
	cout<< "\n||" <<setw(3) << "No" <<setw(3) << "||" <<setw(17) <<"No Rekam Medis" <<setw(5) << "||" <<setw(19 )<<"Nama Pasien" <<setw(12) << "||"<<setw(11)<<"Umur" <<setw(7) << "||" << setw (20) << "Jenis Kelamin" << setw (8) << "||";
	cout<<"\n===========================================================================================================" ;
			arsip_pasien = fopen("pasien1.txt","r");
			fread(&n,sizeof(n),1,arsip_pasien);
			fread(&a,sizeof(a),1,arsip_pasien);
			for (int i=0;i<n;i++)
			{
				fread(&a,sizeof(a),1,arsip_pasien);
						
						cout<<endl<<"||" <<setw(3) <<i+1 << setw(3) <<"||" <<setw(10) <<a[i].no << setw(12) <<"||" <<setw(15)<<a[i].nama << setw(16) <<"||" <<setw(10)<<a[i].umur << setw(8) <<"||"<<setw(14)<<a[i].gender << setw(14) <<"||";
						
	
			}
			cout<<"\n===========================================================================================================";
			fclose(arsip_pasien);
}

void pindah ()
{
	arsip_pasien = fopen("pasien1.txt","r");
	fread(&n,sizeof(n),1,arsip_pasien);
	
	for (int m = 0; m < n ; m++)
	{
		fread(&a,sizeof(a),1,arsip_pasien);
		baru[m].no=a[m].no;
		strcpy(baru[m].nama,a[m].nama);
		baru[m].umur=a[m].umur;
		strcpy(baru[m].gender,a[m].gender);
	
	}
	fclose(arsip_pasien);
}

void tampil_sorting ()
{
	cout << "\n\n\t\t\t\t>>>>>>>>>DATA PASIEN SETELAH URUTKAN<<<<<<<<<<<<\n\n";
	cout<<"\n===========================================================================================================";
	cout<< "\n||" <<setw(3) << "No" <<setw(3) << "||" <<setw(17) <<"No Rekam Medis" <<setw(5) << "||" <<setw(19 )<<"Nama Pasien" <<setw(12) << "||"<<setw(11)<<"Umur" <<setw(7) << "||" << setw (20) << "Jenis Kelamin" << setw (8) << "||";
	cout<<"\n===========================================================================================================" ;
	for (int i = 0; i < n; i++)
				{
					cout<<endl<<"||" <<setw(3) <<i+1 << setw(3) <<"||" <<setw(10) <<baru[i].no << setw(12) <<"||" <<setw(15)<<baru[i].nama << setw(16) <<"||" <<setw(10)<<baru[i].umur << setw(8) <<"||"<<setw(14)<<baru[i].gender << setw(14) <<"||";
				}
			cout<<"\n===========================================================================================================\n" << endl;
}

void bubble_no (int z)
{
	
	int i,j;
	
	cout << ">>>>>>>>Proses Sorting<<<<<<<<<\n\n";
	arsip_pasien = fopen("pasien1.txt","r");
	for (i=0; i<n-1; i++)
	{
				for (j=0; j<n-1-i; j++)
			
				{
					
				switch (z)
				{
				case 1:
				if (baru[j].no > baru[j+1].no)
				{
					swap(baru[j],baru[j+1]);
					
				}break;
				case 2:
				if (baru[j].no < baru[j+1].no)
				{
					swap(baru[j],baru[j+1]);
					
				}break;
				
				}
				
					for (int k = 0; k < n; k++)
						
						cout<<baru[k].no<<" ";
						cout<<endl;	
						
				}		
	}
				
fclose(arsip_pasien);

}

void bubble_nama (int z)
{
	
	int i,j;
	
	cout << ">>>>>>>>Proses Sorting<<<<<<<<<\n\n";
	arsip_pasien = fopen("pasien1.txt","r");
	for (i=0; i<n-1; i++)
	{
				for (j=0; j<n-1-i; j++)
			
				{
					switch (z)
					{
						case 1 :
								if (strcmp(baru[j].nama,baru[j+1].nama)>0)
								{
									swap(baru[j],baru[j+1]);
									
								}break;
						case 2 :
								if (strcmp(baru[j].nama,baru[j+1].nama)<0)
								{
									swap(baru[j],baru[j+1]);
									
								}break;
					}
				
					for (int k = 0; k < n; k++)
						
						cout<<baru[k].nama<<" ";
						cout<<endl;	
						
							
			}	
	}
				
fclose(arsip_pasien);

}

void bubble_umur (int z)
{
	
	int i,j;
	
	cout << ">>>>>>>>Proses Sorting<<<<<<<<<\n\n";
	arsip_pasien = fopen("pasien1.txt","r");
	for (i=0; i<n-1; i++)
	{
				for (j=0; j<n-1-i; j++)
			
				{
					switch (z)
					{
						case 1 :
								if (baru[j].umur > baru[j+1].umur)
								{
									swap(baru[j],baru[j+1]);
									
								}break ;
						case 2 :
								if (baru[j].umur < baru[j+1].umur)
								{
									swap(baru[j],baru[j+1]);
									
								}break;
					}
				
					for (int k = 0; k < n; k++)
						
						cout<<baru[k].umur<<" ";
						cout<<endl;		
						
			}	
	}
				
fclose(arsip_pasien);

}

void bubble_gender (int z)
{
	
	int i,j;
	
	cout << ">>>>>>>>Proses Sorting<<<<<<<<<\n\n";
	arsip_pasien = fopen("pasien1.txt","r");
	for (i=0; i<n-1; i++)
	{
				for (j=0; j<n-1-i; j++)
			
				{
					switch (z)
					{
						case 1 :
								if (strcmp(baru[j].gender,baru[j+1].gender)>0)
								{
									swap(baru[j],baru[j+1]);
									
								}break;
						case 2 :
								if (strcmp(baru[j].gender,baru[j+1].gender)<0)
								{
									swap(baru[j],baru[j+1]);
									
								}break;
					}	
					
					for (int k = 0; k < n; k++)
						
						cout<<baru[k].gender<<" ";
						cout<<endl;
							
				}	
	}
				
fclose(arsip_pasien);

}

void insertion_no (int z)
{
	 
	int i,j,temp,umur1;
		char nama1[30],gender1[10];
		cout << ">>>>>>>>Proses Sorting<<<<<<<<<\n\n";
	for (i=1;i<n;i++)
	{
		temp=baru[i].no;
		strcpy(nama1,baru[i].nama);
		strcpy(gender1,baru[i].gender);
		umur1=baru[i].umur;
		j=i-1;
		switch (z)
		{
		case 1: 
					while ((temp < baru[j].no) && (j>=0))
					{
						baru[j+1].no=baru[j].no;
						strcpy(baru[j+1].nama,baru[j].nama);
						strcpy(baru[j+1].gender,baru[j].gender);
						baru[j+1].umur=baru[j].umur;
									
						j=j-1;
						
						baru[j+1].no=temp;
						strcpy(baru[j+1].nama,nama1);
						strcpy(baru[j+1].gender,gender1);
						baru[j+1].umur=umur1;	
						
						for(int a=0;a<n;a++)
						cout<<baru[a].no<<" ";
						cout<<endl;	
					
						
					}
					break ;
		case 2 :
					while ((temp > baru[j].no) && (j>=0))
					{
						baru[j+1].no=baru[j].no;
						strcpy(baru[j+1].nama,baru[j].nama);
						strcpy(baru[j+1].gender,baru[j].gender);
						baru[j+1].umur=baru[j].umur;
									
						j=j-1;
						
						baru[j+1].no=temp;
						strcpy(baru[j+1].nama,nama1);
						strcpy(baru[j+1].gender,gender1);
						baru[j+1].umur=umur1;	
						
						for(int a=0;a<n;a++)
						cout<<baru[a].no<<" ";
						cout<<endl;	
					
						
					}
					break ;
		}
	}
}

void insertion_nama (int z)
{
	int i,j,temp,umur1;
		char nama1[30],gender1[10];
		cout << ">>>>>>>>Proses Sorting<<<<<<<<<\n\n";
	for (i=1;i<n;i++)
	{
		temp=baru[i].no;
		strcpy(nama1,baru[i].nama);
		strcpy(gender1,baru[i].gender);
		umur1=baru[i].umur;
		j=i-1;
		switch (z)
		{
			case 1 :
					while ((strcmp(nama1,baru[j].nama)<0) && (j>=0))
					{
						baru[j+1].no=baru[j].no;
						strcpy(baru[j+1].nama,baru[j].nama);
						strcpy(baru[j+1].gender,baru[j].gender);
						baru[j+1].umur=baru[j].umur;
									
						j=j-1;
						
						baru[j+1].no=temp;
						strcpy(baru[j+1].nama,nama1);
						strcpy(baru[j+1].gender,gender1);
						baru[j+1].umur=umur1;	
						
					}break;
			case 2 :
					while ((strcmp(nama1,baru[j].nama)>0) && (j>=0))
					{
						baru[j+1].no=baru[j].no;
						strcpy(baru[j+1].nama,baru[j].nama);
						strcpy(baru[j+1].gender,baru[j].gender);
						baru[j+1].umur=baru[j].umur;
									
						j=j-1;
						
						baru[j+1].no=temp;
						strcpy(baru[j+1].nama,nama1);
						strcpy(baru[j+1].gender,gender1);
						baru[j+1].umur=umur1;	
						
					}break;
		}
		for(int a=0;a<n;a++)
						cout<<baru[a].nama<<" ";
						cout<<endl;	
	}
}

void insertion_umur (int z)
{
	int i,j,temp,umur1;
		char nama1[30],gender1[10];
		cout << ">>>>>>>>Proses Sorting<<<<<<<<<\n\n";
	for (i=1;i<n;i++)
	{
		temp=baru[i].no;
		strcpy(nama1,baru[i].nama);
		strcpy(gender1,baru[i].gender);
		umur1=baru[i].umur;
		j=i-1;
		switch (z)
		{
			case 1 :
					
					while ((umur1 < baru[j].umur) && (j>=0))
					{
						baru[j+1].no=baru[j].no;
						strcpy(baru[j+1].nama,baru[j].nama);
						strcpy(baru[j+1].gender,baru[j].gender);
						baru[j+1].umur=baru[j].umur;
									
						j=j-1;
						
						baru[j+1].no=temp;
						strcpy(baru[j+1].nama,nama1);
						strcpy(baru[j+1].gender,gender1);
						baru[j+1].umur=umur1;		
					}break;
			case 2 :
					while ((umur1 > baru[j].umur) && (j>=0))
					{
						baru[j+1].no=baru[j].no;
						strcpy(baru[j+1].nama,baru[j].nama);
						strcpy(baru[j+1].gender,baru[j].gender);
						baru[j+1].umur=baru[j].umur;
									
						j=j-1;
						
						baru[j+1].no=temp;
						strcpy(baru[j+1].nama,nama1);
						strcpy(baru[j+1].gender,gender1);
						baru[j+1].umur=umur1;		
					}break;
		}
		for(int a=0;a<n;a++)
			cout<<baru[a].umur<<" ";
			cout<<endl;	
		
	}
}

void insertion_gender (int z)
{
	int i,j,temp,umur1;
		char nama1[30],gender1[10];
		cout << ">>>>>>>>Proses Sorting<<<<<<<<<\n\n";
	for (i=1;i<n;i++)
	{
		temp=baru[i].no;
		strcpy(nama1,baru[i].nama);
		strcpy(gender1,baru[i].gender);
		umur1=baru[i].umur;
		j=i-1;
		switch (z)
		{
			case 1 :
						while ((strcmp(gender1,baru[j].gender)<0) && (j>=0))
						{
							baru[j+1].no=baru[j].no;
							strcpy(baru[j+1].nama,baru[j].nama);
							strcpy(baru[j+1].gender,baru[j].gender);
							baru[j+1].umur=baru[j].umur;
										
							j=j-1;
							
							baru[j+1].no=temp;
							strcpy(baru[j+1].nama,nama1);
							strcpy(baru[j+1].gender,gender1);
							baru[j+1].umur=umur1;								
						}break;
			case 2 :
						while ((strcmp(gender1,baru[j].gender)>0) && (j>=0))
						{
							baru[j+1].no=baru[j].no;
							strcpy(baru[j+1].nama,baru[j].nama);
							strcpy(baru[j+1].gender,baru[j].gender);
							baru[j+1].umur=baru[j].umur;
										
							j=j-1;
							
							baru[j+1].no=temp;
							strcpy(baru[j+1].nama,nama1);
							strcpy(baru[j+1].gender,gender1);
							baru[j+1].umur=umur1;								
						}break;
	}
	for(int a=0;a<n;a++)
			cout<<baru[a].gender<<" ";
			cout<<endl;	
	}
}

void selection_no (int z)
{
	int i,j;
	
	cout << ">>>>>>>>Proses Sorting<<<<<<<<<\n\n";
	for (i=0; i<n; i++)
	{
				for (j=i+1; j<n; j++)
				switch (z)
				{
					case 1 :
							if (baru[i].no > baru[j].no)
							{
								swap(baru[i],baru[j]);	
							}break;
					case 2 :
							if (baru[i].no < baru[j].no)
							{
								swap(baru[i],baru[j]);	
							}break;
					
				}
		for(int a=0;a<n;a++)
			cout<<baru[a].no<<" ";
			cout<<endl;
	}
}

void selection_nama (int z)
{
	int i,j;
	
	cout << ">>>>>>>>Proses Sorting<<<<<<<<<\n\n";
	for (i=0; i<n; i++)
	{
				for (j=i+1; j<n; j++)
				switch (z)
				{
					case 1 :
								if (strcmp(baru[i].nama, baru[j].nama)>0)
								{
								swap(baru[i],baru[j]);
								}break;
					case 2 :
								if (strcmp(baru[i].nama, baru[j].nama)<0)
								{
								swap(baru[i],baru[j]);
								}break;
								
				}
		for(int a=0;a<n;a++)
			cout<<baru[a].nama<<" ";
			cout<<endl;
	}
}

void selection_umur (int z)
{
	int i,j;

	cout << ">>>>>>>>Proses Sorting<<<<<<<<<\n\n";
	for (i=0; i<n; i++)
	{
				for (j=i+1; j<n; j++)
				switch (z)
				{
					case 1 :
					
							if (baru[i].umur > baru[j].umur)
							{
								swap(baru[i],baru[j]);
							}break;
					case 2 :
							if (baru[i].umur < baru[j].umur)
							{
								swap(baru[i],baru[j]);
							}break;
				}
				
		for(int a=0;a<n;a++)
			cout<<baru[a].umur<<" ";
			cout<<endl;
	}
}

void selection_gender (int z)
{
	int i,j;
	
	cout << ">>>>>>>>Proses Sorting<<<<<<<<<\n\n";
	for (i=0; i<n; i++)
	{
				for (j=i+1; j<n; j++)
				switch (z)
				{
					case 1 :
							if (strcmp(baru[i].gender, baru[j].gender)>0)
							{
								swap(baru[i],baru[j]);	
							}break;
					case 2 :
							if (strcmp(baru[i].gender, baru[j].gender)<0)
							{
								swap(baru[i],baru[j]);	
							}break;
					
				}
		for(int a=0;a<n;a++)
			cout<<baru[a].gender<<" ";
			cout<<endl;
	}
}

void shell_no (int z)
{
	
	int i=0,j=0,k=0;
	cout << ">>>>>>>>Proses Sorting<<<<<<<<<\n\n";
	for (k=n/2;k>0;k/=2)
	{
		for (j=k;j<n;j++)
		{
			for (i=j-k;i>=0;i-=k)
			{
				switch (z)
				{
					case 1 :
								if (baru[i+k].no >= baru[i].no)
								{
									break;
								}
								else
								{
									swap(baru[i],baru[i+k]);
								}break;
					case 2 :
								if (baru[i+k].no <= baru[i].no)
								{
									break;
								}
								else
								{
									swap(baru[i],baru[i+k]);
								}break;
				}
				
				for (int l=0;l<n;l++)
					
						cout << baru[l].no << "  ";
					
					cout << endl;
			}
		}
	}	
}

void shell_nama (int z)
{

	int i=0,j=0,k=0;
	cout << ">>>>>>>>Proses Sorting<<<<<<<<<\n\n";
	for (k=n/2;k>0;k/=2)
	{
		for (j=k;j<n;j++)
		{
			for (i=j-k;i>=0;i-=k)
			{
				switch (z)
				{
					case 1 : 
								if (strcmp(baru[i+k].nama,baru[i].nama)>=0)
								{
									break;
								}
								else
								{
									swap(baru[i],baru[i+k]);
								}break;
					case 2 :
								if (strcmp(baru[i+k].nama,baru[i].nama)<=0)
								{
									break;
								}
								else
								{
									swap(baru[i],baru[i+k]);
								}break;
					
					
				
				}
									for (int l=0;l<n;l++)
									{
										cout << baru[l].nama << "  ";
									}
									cout << endl;
			}
		}
	}	
}

void shell_umur (int z)
{
	
	int i=0,j=0,k=0;
	cout << ">>>>>>>>Proses Sorting<<<<<<<<<\n\n";
	for (k=n/2;k>0;k/=2)
	{
		for (j=k;j<n;j++)
		{
			for (i=j-k;i>=0;i-=k)
			{
				switch (z)
				{
					case 1 :
								if (baru[i+k].umur >= baru[i].umur)
								{
									break;
								}
								else
								{
									swap(baru[i],baru[i+k]);
								}break ;
					case 2 :
								if (baru[i+k].umur <= baru[i].umur)
								{
									break;
								}
								else
								{
									swap(baru[i],baru[i+k]);
								}break ;
					
					
				}
				for (int l=0;l<n;l++)
					{
						cout << baru[l].umur << "  ";
					}
					cout << endl;
			}
		}
	}
}	


void shell_gender (int z)
{

	int i=0,j=0,k=0;
	cout << ">>>>>>>>Proses Sorting<<<<<<<<<\n\n";
	for (k=n/2;k>0;k/=2)
	{
		for (j=k;j<n;j++)
		{
			for (i=j-k;i>=0;i-=k)
			{
				switch (z)
				{
					case 1 :
							if (strcmp(baru[i+k].gender,baru[i].gender)>=0)
							{
								break;
							}
							else
							{
								swap(baru[i],baru[i+k]);
							}break;
					case 2 :
							if (strcmp(baru[i+k].gender,baru[i].gender)<=0)
							{
								break;
							}
							else
							{
								swap(baru[i],baru[i+k]);
							}break;
					
					
				
				}
					for (int l=0;l<n;l++)
					{
						cout << baru[l].gender << "  ";
					}
					cout << endl;
			}
		}
	}	
}

void quick_no (int first, int last , int z)
{
	
	int low,high,list_separator;
	
	

	low=first;
	high=last;
	list_separator=baru[(first+last)/2].no;
	
	do
	{
		
		switch (z)
		{
			case 1 :
					while (baru[low].no<list_separator) low++;
					while (baru[high].no>list_separator) high--;
					if (low<=high)
						{
							
							swap(baru[low],baru[high]);
							low++;	high--;
						}break;
			case 2 :
					while (baru[low].no>list_separator) low++;
					while (baru[high].no<list_separator) high--;
					if (low<=high)
						{
							
							swap(baru[low],baru[high]);
							low++;	high--;
						}break;
		}
		for (int j=0;j<n;j++)
				cout << baru[j].no << "  " ;
			cout << endl;
	}
	while (low<=high);

	if (first<high) quick_no(first, high, z);
	if (low<last) quick_no(low, last, z);
	
}

void quick_nama (int first, int last, int z)
{
	int low,high;
	char list_separator[30];
	
	

	low=first;
	high=last;
	strcpy(list_separator,baru[(first+last)/2].nama);

	do
	{
		switch (z)
		{
			case 1 :
					while (strcmp(baru[low].nama,list_separator)<0) low++;
					while (strcmp (baru[high].nama,list_separator)>0) high--;
					if (low<=high)
						{
							
							swap(baru[low],baru[high]);
							low++;	high--;
						}break;
			case 2 :
					while (strcmp(baru[low].nama,list_separator)>0) low++;
					while (strcmp (baru[high].nama,list_separator)<0) high--;
					if (low<=high)
						{
							
							swap(baru[low],baru[high]);
							low++;	high--;
						}break;				
		}
				for (int j=0;j<n;j++)
				cout << baru[j].nama << "  " ;
				cout << endl;
	}
	while (low<=high);
	
	if (first<high) quick_nama(first, high, z);
	if (low<last) quick_nama(low, last, z);
	
}

void quick_umur (int first, int last, int z)
{
	int low,high,list_separator;
	
	

	low=first;
	high=last;
	list_separator=baru[(first+last)/2].umur;

	do
	{
		switch (z)
		{
			case 1 :
						while (baru[low].umur<list_separator) low++;
						while (baru[high].umur>list_separator) high--;
						if (low<=high)
							{
								
								swap(baru[low],baru[high]);
								low++;	high--;
							}break;
			case 2 :
						while (baru[low].umur>list_separator) low++;
						while (baru[high].umur<list_separator) high--;
						if (low<=high)
							{
								
								swap(baru[low],baru[high]);
								low++;	high--;
							}break;
		}
		for (int j=0;j<n;j++)
				cout << baru[j].umur << "  " ;
			cout << endl;

	}
	while (low<=high);
	
	if (first<high) quick_umur(first, high, z);
	if (low<last) quick_umur(low, last, z);
	
}

void quick_gender (int first, int last, int z)
{
	int low,high;
	char list_separator[100];
	low=first;
	high=last;
	strcpy(list_separator,baru[(first+last)/2].gender);

	do
	{
		switch (z)
		{
			case 1 :
					while (strcmp(baru[low].gender,list_separator)<0) low++;
					while (strcmp(baru[high].gender,list_separator)>0) high--;
					if (low<=high)
						{				
							swap(baru[low],baru[high]);
							low++;	high--;
						}break;
			case 2 :
					while (strcmp(baru[low].gender,list_separator)>0) low++;
					while (strcmp(baru[high].gender,list_separator)<0) high--;
					if (low<=high)
						{				
							swap(baru[low],baru[high]);
							low++;	high--;
						}break;
			
		}
			for (int j=0;j<n;j++)
				cout << baru[j].gender << "  " ;
			cout << endl;
	}
	while (low<=high);
	
	if (first<high) quick_gender(first, high, z);
	if (low<last) quick_gender(low, last, z);
	
}

void seq_no ()
{
										int no1;
										int i,j;
										j=0;
						
										arsip_pasien = fopen("pasien1.txt","r");
										fread(&n,sizeof(n),1,arsip_pasien);
										fread(&a,sizeof(a),1,arsip_pasien);
										cout << "Nomor Rekam Medis = "; 
										cin >> no1;
			
											for(i=0;i<n;i++)
											{
												fread(&a,sizeof(a),1,arsip_pasien);
												if (a[i].no==no1)
												{
													cout << "\n---Pasien" << i+1 << "---" << endl;
													cout << "\nNo Rekam Medis : " << a[i].no;
													cout << "\nNama Pasien : " << a[i].nama;
													cout << "\nUmur Pasien : " << a[i].umur;
													cout << "\nJenis Kelamin : " << a[i].gender << endl;
													j=1;
												}cout << "\n\n";
											}
											if(j!=1)
											cout << "File Tidak Ada\n";
											fclose(arsip_pasien);
}

void seq_nama ()
{
	char nama1[100];
										int i,j,tempat1;
										j=0;
						
										arsip_pasien = fopen("pasien1.txt","r");
										fread(&n,sizeof(n),1,arsip_pasien);
										fread(&a,sizeof(a),1,arsip_pasien);
										
										cout << "Masukkan Nama Yang Ingin Dicari = "; cin.ignore ();
										gets(nama1);
			
			
											for(i=0;i<n;i++)
											{
												fread(&a,sizeof(a),1,arsip_pasien);
												tempat1= strcmp(nama1 , a[i].nama);
												if (tempat1==0)
												{
													cout << "\n---Pasien" << i+1 << "---" << endl;
													cout << "\nNo Rekam Medis : " << a[i].no;
													cout << "\nNama Pasien : " << a[i].nama;
													cout << "\nUmur Pasien : " << a[i].umur;
													cout << "\nJenis Kelamin : " << a[i].gender << endl;
													j=1;
												}cout << "\n\n";
											}
											if(j!=1)
											cout << "File Tidak Ada\n";
											fclose(arsip_pasien);
}

void seq_umur()
{
	int umur1;
										int i,j;
										j=0;
						
										arsip_pasien = fopen("pasien1.txt","r");
										fread(&n,sizeof(n),1,arsip_pasien);
										fread(&a,sizeof(a),1,arsip_pasien);
										cout << "Masukkan Umur Berapa Yang Ingin Dicari = "; 
										cin >> umur1;
			
			
											for(i=0;i<n;i++)
											{
												fread(&a,sizeof(a),1,arsip_pasien);
												if (a[i].umur==umur1)
												{
													cout << "\n---Pasien" << i+1 << "---" << endl;
													cout << "\nNo Rekam Medis : " << a[i].no;
													cout << "\nNama Pasien : " << a[i].nama;
													cout << "\nUmur Pasien : " << a[i].umur;
													cout << "\nJenis Kelamin : " << a[i].gender << endl;
													j=1;
												}cout << "\n\n";
											}
											if(j!=1)
											cout << "File Tidak Ada\n";
											fclose(arsip_pasien);
}

void seq_gender ()
{
	char gender1[10];
										int i,j,tempat;
										j=0;
						
										arsip_pasien = fopen("pasien1.txt","r");
										fread(&n,sizeof(n),1,arsip_pasien);
										fread(&a,sizeof(a),1,arsip_pasien);
										cout << "Masukkan Jenis Kelamin Yang Ingin Dicari = "; 
										cin >> gender1;
			
			
											for(i=0;i<n;i++)
											{
												fread(&a,sizeof(a),1,arsip_pasien);
												tempat= strcmp(gender1 , a[i].gender);
												if (tempat==0)
												{
													cout << "\n---Pasien" << i+1 << "---" << endl;
													cout << "\nNo Rekam Medis : " << a[i].no;
													cout << "\nNama Pasien : " << a[i].nama;
													cout << "\nUmur Pasien : " << a[i].umur;
													cout << "\nJenis Kelamin : " << a[i].gender << endl;
													j=1;
												}cout << "\n\n";
											}
											if(j!=1)
											cout << "File Tidak Ada\n";
											fclose(arsip_pasien);
}

void bin_no()
{
	int no2,tengah,tanda,kanan,kiri;
											pindah();
											cout<<"\nMasukkan nomor yang dicari = ";
											cin>>no2;
											
											for (int i=0; i<n-1; i++)
											{
														for (int j=0; j<n-1-i; j++)
														
														if (baru[j].no > baru[j+1].no)
														{
															
															swap(baru[j],baru[j+1]);

														}		
											
											}
											tanda=0;
											kiri=0;
											kanan=n-1;
											while((kiri<=kanan)&(tanda==0))
											{
												fread(&a,sizeof(a),1,arsip_pasien);//hapus				
												tengah=(kiri+kanan)/2;
												if(no2==baru[tengah].no)
												{
													tanda=1;
													cout << "\nNo Rekam Medis : " << baru[tengah].no;
													cout << "\nNama Pasien : " << baru[tengah].nama;
													cout << "\nUmur Pasien : " << baru[tengah].umur;
													cout << "\nJenis Kelamin : " << baru[tengah].gender << endl;
												}
												else 
												{	
													if(no2<baru[tengah].no)
													kanan=tengah-1;
													else
													kiri=tengah+1;
												}
											}
											cout<<endl;
											if(tanda==0)
											cout<<"pasien yang dicari tidak ditemukan";
											fclose(arsip_pasien);
}

void bin_nama()
{
	int tengah,tanda,kanan,kiri;
											char nama1[30];
											pindah();
											cout<<"\nMasukkan nama yang dicari = "; cin.ignore ();
											gets(nama1);
											
											for (int i=0; i<n; i++)
											{
												for (int j=i+1; j<n; j++)
												if (strcmp(baru[i].nama, baru[j].nama))
												{
												swap(baru[i],baru[j]);
												}
											}
											
											tanda=0;
											kiri=0;
											kanan=n-1;
											while((kiri<=kanan)&&(tanda==0))
											{
												fread(&n,sizeof(n),1,arsip_pasien);				
												tengah=(kiri+kanan)/2;
												if(strcmp(baru[tengah].nama,nama1)==0)
												{
													tanda=1;
													cout << "\nNo Rekam Medis : " << baru[tengah].no;
													cout << "\nNama Pasien : " << baru[tengah].nama;
													cout << "\nUmur Pasien : " << baru[tengah].umur;
													cout << "\nJenis Kelamin : " << baru[tengah].gender << endl;
												}
												else 
												{	
													if(strcmp(nama1,baru[tengah].nama)>0)
													kanan=tengah-1;
													else
													kiri=tengah+1;
												}
											}
											cout<<endl;
											if(tanda==0)
											cout<<"Pasien yang dicari tidak ditemukan\n";
										fclose(arsip_pasien);
}

void bin_umur ()
{
	int tengah,tanda,kanan,kiri,umur2;
											pindah();
											cout<<"\nMasukkan umur yang dicari = ";
											cin>>umur2;
											for (int i=0; i<n-1; i++)
											{
														for (int j=0; j<n-1-i; j++)
														
														if (baru[j].umur > baru[j+1].umur)
														{
															
															swap(baru[j],baru[j+1]);

														}		
											
											tanda=0;
											kiri=0;
											kanan=n-1;
											while((kiri<=kanan)&(tanda==0))
											{
												fread(&n,sizeof(n),1,arsip_pasien);				
												tengah=(kiri+kanan)/2;
												if(umur2==baru[tengah].umur)
												{
													tanda=1;
													cout << "\nNo Rekam Medis : " << baru[tengah].no;
													cout << "\nNama Pasien : " << baru[tengah].nama;
													cout << "\nUmur Pasien : " << baru[tengah].umur;
													cout << "\nJenis Kelamin : " << baru[tengah].gender << endl;
												}
												else 
												{	
													if(umur2<baru[tengah].umur)
													kanan=tengah-1;
													else
													kiri=tengah+1;
												}
											}
											cout<<endl;
											if(tanda==0)
											cout<<"Pasien yang dicari tidak ditemukan";
						}
									fclose(arsip_pasien);

}

void bin_gender ()
{
		int tengah,tanda,kanan,kiri;
											char gender1[30];
											pindah();
											cout<<"\nMasukkan gender yang dicari = "; cin.ignore ();
											gets(gender1);
											for (int i=0; i<n-1; i++)
											{
														for (int j=0; j<n-1-i; j++)
														
														if (strcmp(baru[j].gender, baru[j+1].gender))
														{
															
															swap(baru[j],baru[j+1]);

														}		
											
											}
											
											tanda=0;
											kiri=0;
											kanan=n-1;
											while((kiri<=kanan)&(tanda==0))
											{
												fread(&a,sizeof(a),1,arsip_pasien);				
												tengah=(kiri+kanan)/2;
												if(strcmp(baru[tengah].gender,gender1)==0)
												{
													tanda=1;
													cout << "\nNo Rekam Medis : " << baru[tengah].no;
													cout << "\nNama Pasien : " << baru[tengah].nama;
													cout << "\nUmur Pasien : " << baru[tengah].umur;
													cout << "\nJenis Kelamin : " << baru[tengah].gender << endl;
												}
												else 
												{	
													if(strcmp(gender1,baru[tengah].gender)>0)
													kanan=tengah-1;
													else
													kiri=tengah+1;
												}
											}
											cout<<endl;
											if(tanda==0)
											cout<<"Pasien yang dicari tidak ditemukan";
										fclose(arsip_pasien);
}
	
